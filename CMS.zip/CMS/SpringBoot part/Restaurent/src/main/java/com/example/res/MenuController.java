package com.example.res;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MenuController {
	@Autowired
	private MenuService menuService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("showMenu")
	public Menu[] show() {
		return menuService.showMenu();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("searchMenu/{restaurentId}")
	public Menu[] searchMenu(@PathVariable int restaurentId) {
		return menuService.searchMenu(restaurentId);
	}
	
	@RequestMapping("/searchByMenuId/{menuId}")
	public Menu searchMenus(@PathVariable int menuId) {
		return menuService.searchMenus(menuId);
	}


}
