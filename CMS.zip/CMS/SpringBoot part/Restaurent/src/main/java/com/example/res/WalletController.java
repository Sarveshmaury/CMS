package com.example.res;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WalletController {
	@Autowired
	private WalletService walletService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("searchCustomerWallet/{customerId}")
	public Wallet[] searchCustomerWallet(@PathVariable int customerId) {
		return walletService.searchCustomerWallet(customerId);
	}
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("/searchWallet/{walletId}")
	public Wallet searchWallet(@PathVariable int walletId) {
		return walletService.searchWallet(walletId);
	}
	

}
