package com.example.res;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestaurentController {
	@Autowired
	private RestaurentService restaurentService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("showRestaurent")
	public Restaurent[] show() {
		return restaurentService.showRestaurent();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("searchRestaurent/{restaurentId}")
	public Restaurent searchRestaurent(@PathVariable int restaurentId) {
		return restaurentService.searchRestaurent(restaurentId);
	}

}
