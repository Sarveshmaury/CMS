package com.example.res;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class RestaurentService {
	@Autowired
	RestaurentDAO dao;
	
	public Restaurent[] showRestaurent() {
		return dao.showRestaurent();
	}
	
	public Restaurent searchRestaurent(int restaurentId) {
		return dao.searchRestaurent(restaurentId);
	}

}
