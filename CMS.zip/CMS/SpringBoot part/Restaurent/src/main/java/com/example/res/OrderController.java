package com.example.res;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {
	@Autowired
	private OrderService orderService;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("showPendingOrder")
	public Order[] show() {
		return orderService.showPendingOrder();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("searchCustomerOrder/{customerId}")
	public Order[] searchCustomerOrder(@PathVariable int customerId) {
		return orderService.searchCustomerOrder(customerId);
	}
	//-------------
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("searchCustomerPendingOrder/{customerId}")
	public Order[] searchCustomerPendingOrder(@PathVariable int customerId) {
		return orderService.searchCustomerOrder(customerId);
	}
	
	//-------
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("searchVendorOrder/{vendorId}")
	public Order[] searchVendorOrder(@PathVariable int vendorId) {
		return orderService.searchVendorOrder(vendorId);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("searchVendorPendingOrder/{vendorId}")
	public Order[] searchVendorPendingOrder(@PathVariable int vendorId) {
		return orderService.searchCustomerOrder(vendorId);
	}
	//------------------------------------
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping("/orderSearch/{orderId}")
	public Order orderSearch(@PathVariable int orderId) {
		return orderService.searchOrder(orderId);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/acceptOrRejectOrder/{orderId}/{vendorId}/{status}")
	public String acceptOrReject(@PathVariable int orderId,@PathVariable int vendorId,
	@PathVariable String status) {
	return orderService.acceptOrRejectOrder(orderId, vendorId, status);
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/order/placeOrder")
	public String add(@RequestBody Order order) {
	return orderService.placeOrder(order);
	}
	//-------------------------------------


}
