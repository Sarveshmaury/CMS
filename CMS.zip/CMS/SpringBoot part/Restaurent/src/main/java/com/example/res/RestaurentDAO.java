package com.example.res;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;


@Repository
public class RestaurentDAO {

	@Autowired
    JdbcTemplate jdbcTemplate;

	public Restaurent searchRestaurent(int restaurentId) {
		String cmd = "select * from Restaurent where restaurentId=?";
		List<Restaurent> restaurentList = jdbcTemplate.query(cmd, new Object[] {restaurentId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Restaurent restaurent = new Restaurent();
				restaurent.setrestaurentId(rs.getInt("restaurentId"));
				restaurent.setrestaurentName(rs.getString("restaurentName"));
				restaurent.setrestaurentCity(rs.getString("restaurentCity"));
				restaurent.setrestaurentBranch(rs.getString("restaurentBranch"));
				restaurent.setrestaurentEmail(rs.getString("restaurentEmail"));
				restaurent.setrestaurentContactNo(rs.getString("restaurentContactNo"));	
				return restaurent;
			}
		});
		if (restaurentList.size()==1) {
			return restaurentList.get(0);
		}
		return null;
	}

	public Restaurent[] showRestaurent() {
		String cmd = "select * from Restaurent";
		List<Restaurent> restaurentList = null;
		restaurentList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Restaurent restaurent = new Restaurent();
				restaurent.setrestaurentId(rs.getInt("restaurentId"));
				restaurent.setrestaurentName(rs.getString("restaurentName"));
				restaurent.setrestaurentCity(rs.getString("restaurentCity"));
				restaurent.setrestaurentBranch(rs.getString("restaurentBranch"));
				restaurent.setrestaurentEmail(rs.getString("restaurentEmail"));
				restaurent.setrestaurentContactNo(rs.getString("restaurentContactNo"));
				return restaurent;
			}
		});
		return restaurentList.toArray(new Restaurent[restaurentList.size()]);
	}

}
