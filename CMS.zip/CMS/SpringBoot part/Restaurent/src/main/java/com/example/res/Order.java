package com.example.res;
import java.util.Date;

public class Order {
	private int orderId;
	private int vendorId;
	private int customerId;
	private int menuId;
	private int walletId;
	private Date orderDate;
	private int quantityOrdered;
	private String orderStatus;
	private int billAmount;
	private String comments;
	
	
	public int getorderId() {
		return orderId;
	}
	public void setorderId(int orderId) {
		this.orderId = orderId;
	}
	public int getvendorId() {
		return vendorId;
	}
	public void setvendorId(int vendorId) {
		this.vendorId = vendorId;
	}
	public int getcustomerId() {
		return customerId;
	}
	public void setcustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getmenuId() {
		return menuId;
	}
	public void setmenuId(int menuId) {
		this.menuId = menuId;
	}
	public int getwalletId() {
		return walletId;
	}
	public void setwalletId(int walletId) {
		this.walletId = walletId;
	}
	
	public Date getorderDate() {
		return orderDate;
	}
	public void setorderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public int getquantityOrdered() {
		return quantityOrdered;
	}
	public void setquantityOrdered(int quantityOrdered) {
		this.quantityOrdered = quantityOrdered;
	}
	public String getorderStatus() {
		return orderStatus;
	}
	public void setorderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}
	public int getbillAmount() {
		return billAmount;
	}
	public void setbillAmount(int billAmount) {
		this.billAmount = billAmount;
	}
	public String getcomments() {
		return comments;
	}
	public void setcomments(String comments) {
		this.comments = comments;
	}
	
	
	public Order() {
		// TODO Auto-generated constructor stub
	}

	public Order(int orderId, int vendorId, int customerId,int menuId, int walletId,Date orderDate,int quantityOrdered,String orderStatus,int billAmount,String comments ) {
		this.orderId = orderId;
		this.vendorId = vendorId;
		this.customerId = customerId;
		this.menuId=menuId;
		this.walletId = walletId;
		this.orderDate=orderDate;
		this.quantityOrdered = quantityOrdered;
		this.orderStatus = orderStatus;
		this.billAmount=billAmount;
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", vendorId=" + vendorId + ", customerId=" + customerId + ",  menuId=" + menuId + ", walletId=" + walletId + " , orderDate=" + orderDate + ", quantityOrdered=" + quantityOrdered + " , orderStatus=" + orderStatus + ", billAmount=" + billAmount + ", comments=" + comments + "]";
	}


}
