package com.example.res;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurentApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurentApplication.class, args);
	}

}
