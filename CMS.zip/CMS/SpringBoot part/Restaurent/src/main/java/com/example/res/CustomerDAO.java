package com.example.res;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDAO {
	
	@Autowired
    JdbcTemplate jdbcTemplate;

	public Customer searchCustomer(int customerId) {
		String cmd = "select * from Customers where customerId=?";
		List<Customer> customerList = jdbcTemplate.query(cmd, new Object[] {customerId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer.setcustomerId(rs.getInt("customerId"));
				customer.setcustomername(rs.getString("customername"));
				customer.setcustomerState(rs.getString("customerState"));
				customer.setcustomerCity(rs.getString("customerCity"));
				customer.setcustomerEmail(rs.getString("customerEmail"));
				customer.setcustomerMob(rs.getString("customerMob"));	
				return customer;
			}
		});
		if (customerList.size()==1) {
			return customerList.get(0);
		}
		return null;
	}

	public Customer[] showCustomer() {
		String cmd = "select * from Customers";
		List<Customer> customerList = null;
		customerList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Customer customer = new Customer();
				customer.setcustomerId(rs.getInt("customerId"));
				customer.setcustomername(rs.getString("customername"));
				customer.setcustomerState(rs.getString("customerState"));
				customer.setcustomerCity(rs.getString("customerCity"));
				customer.setcustomerEmail(rs.getString("customerEmail"));
				customer.setcustomerMob(rs.getString("customerMob"));
				return customer;
			}
		});
		return customerList.toArray(new Customer[customerList.size()]);
	}

}
