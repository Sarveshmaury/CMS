package com.example.res;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class OrderService {
	@Autowired
	OrderDAO dao;
	
	public Order[] showPendingOrder() {
		return dao.showPendingOrder();
	}
	
	
	public Order[] searchCustomerOrder(int customerId) {
		return dao.searchCustomerOrder(customerId);
	}
	
	public Order[] searchVendorOrder(int vendorId) {
		return dao.searchVendorOrder(vendorId);
	}
	//-------------------
	public Order[] searchCustomerPendingOrder(int customerId) {
		return dao.searchCustomerOrder(customerId);
	}
	
	public Order[] searchVendorPendingOrder(int vendorId) {
		return dao.searchCustomerOrder(vendorId);
	}
	//-----------
	public Order searchOrder(int orderId) {
		return dao.searchOrder(orderId);
	}
	
	public String placeOrder(Order order) {
		return dao.placeOrder(order);
	}
	
	public String acceptOrRejectOrder(int orderId, int vendorId, String status) {
		return dao.acceptOrRejectOrder(orderId, vendorId, status);
	}
	//----

}
