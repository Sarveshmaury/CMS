package com.example.res;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class WalletDAO {
	@Autowired
    JdbcTemplate jdbcTemplate;

	public List<Wallet> searchCustomerWallet(int customerId) {
		String cmd = "select * from wallet where customerId=?";
		List<Wallet> walletList = jdbcTemplate.query(cmd, new Object[] {customerId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Wallet wallet = new Wallet();
				wallet.setwalletId(rs.getInt("walletId"));
				wallet.setcustomerId(rs.getInt("customerId"));
				wallet.setwalletType(rs.getString("walletType"));
				wallet.setAmount(rs.getInt("Amount"));
				return wallet;
			}
		});
		return walletList;

	}
	//----------
	public String deductBalance(int walletId, int billAmount) {
		String cmd = "update wallet set Amount=Amount-? where walletId=?";
		jdbcTemplate.update(cmd, new Object[] {billAmount,walletId});
		return "Amount Deducted...";
	}
	
	public Wallet searchWallet(int walletId) {
		String cmd = "select * from wallet where walletId=?";
		List<Wallet> walletList = jdbcTemplate.query(cmd, 
				new Object[] {walletId}, new RowMapper(){
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
						Wallet wallet = new Wallet();
						wallet.setwalletId(rs.getInt("walletId"));
						wallet.setcustomerId(rs.getInt("customerId"));
						wallet.setwalletType(rs.getString("walletType"));
						wallet.setAmount(rs.getInt("Amount"));
						return wallet;
					}
		});
		return walletList.get(0);
		
	}
	//-----------

}
