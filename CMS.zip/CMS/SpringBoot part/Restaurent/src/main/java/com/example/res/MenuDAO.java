package com.example.res;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;


@Repository
public class MenuDAO {
	@Autowired
    JdbcTemplate jdbcTemplate;
	
	public Menu[] searchMenu(int restaurentId) {
		String cmd = "select * from Menu where restaurentId=?";
		List<Menu> menuList = jdbcTemplate.query(cmd, new Object[] {restaurentId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Menu menu = new Menu();
				menu.setmenuId(rs.getInt("menuId"));
				menu.setrestaurentId(rs.getInt("restaurentId"));
				menu.setItemName(rs.getString("ItemName"));
				menu.setmenuType(rs.getString("menuType"));
				menu.setprice(rs.getInt("price"));
				return menu;
			}
		});
		
		return menuList.toArray(new Menu[menuList.size()]);
	}

	public Menu[] showMenu() {
		String cmd = "select * from Menu";
		List<Menu> menuList = null;
		menuList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Menu menu = new Menu();
				menu.setmenuId(rs.getInt("menuId"));
				menu.setrestaurentId(rs.getInt("restaurentId"));
				menu.setItemName(rs.getString("ItemName"));
				menu.setmenuType(rs.getString("menuType"));
				menu.setprice(rs.getInt("price"));
				return menu;
			}
		});
		return menuList.toArray(new Menu[menuList.size()]);
	}
	//--------
	public Menu searchMenus(int menuId)  {
		String cmd = "select * from Menu where menuId=?";
		List<Menu> menuList = jdbcTemplate.query(cmd, 
				new Object[] {menuId}, new RowMapper(){
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
						Menu menu = new Menu();
						menu.setmenuId(rs.getInt("menuId"));
						menu.setrestaurentId(rs.getInt("restaurentId"));
						menu.setItemName(rs.getString("ItemName"));
						menu.setmenuType(rs.getString("menuType"));
						menu.setprice(rs.getInt("price"));
						return menu;
					}
		});
		return menuList.get(0);
	}
	//-------


}
