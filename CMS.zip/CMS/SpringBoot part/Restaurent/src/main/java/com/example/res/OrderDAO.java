package com.example.res;
import java.util.Date;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class OrderDAO {
	@Autowired
    JdbcTemplate jdbcTemplate;

	public Order[] searchCustomerOrder(int customerId) {
		String cmd = "select * from Orders where customerId=?";
		List<Order> orderList = jdbcTemplate.query(cmd, new Object[] {customerId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order order = new Order();
				order.setorderId(rs.getInt("orderId"));
				order.setvendorId(rs.getInt("vendorId"));
				order.setcustomerId(rs.getInt("customerId"));
				order.setmenuId(rs.getInt("menuId"));
				order.setwalletId(rs.getInt("walletId"));
				order.setorderDate(rs.getDate("orderDate"));
				order.setquantityOrdered(rs.getInt("quantityOrdered"));
				order.setorderStatus(rs.getString("orderStatus"));
				order.setbillAmount(rs.getInt("billAmount"));
				order.setcomments(rs.getString("comments"));
				return order;
			}
		});
		return orderList.toArray(new Order[orderList.size()]);
	}

	public Order[] searchVendorOrder(int vendorId) {
		String cmd = "select * from Orders where vendorId=?";
		List<Order> orderList = jdbcTemplate.query(cmd, new Object[] {vendorId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order order = new Order();
				order.setorderId(rs.getInt("orderId"));
				order.setvendorId(rs.getInt("vendorId"));
				order.setcustomerId(rs.getInt("customerId"));
				order.setmenuId(rs.getInt("menuId"));
				order.setwalletId(rs.getInt("walletId"));
				order.setorderDate(rs.getDate("orderDate"));
				order.setquantityOrdered(rs.getInt("quantityOrdered"));
				order.setorderStatus(rs.getString("orderStatus"));
				order.setbillAmount(rs.getInt("billAmount"));
				order.setcomments(rs.getString("comments"));
				return order;
			}
		});
		return orderList.toArray(new Order[orderList.size()]);
	}
	public Order[] showPendingOrder() {
		String cmd = "select * from Orders where orderStatus='pending'";
		List<Order> orderList = null;
		orderList = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order order = new Order();
				order.setorderId(rs.getInt("orderId"));
				order.setvendorId(rs.getInt("vendorId"));
				order.setcustomerId(rs.getInt("customerId"));
				order.setmenuId(rs.getInt("menuId"));
				order.setwalletId(rs.getInt("walletId"));
				order.setorderDate(rs.getDate("orderDate"));
				order.setquantityOrdered(rs.getInt("quantityOrdered"));
				order.setorderStatus(rs.getString("orderStatus"));
				order.setbillAmount(rs.getInt("billAmount"));
				order.setcomments(rs.getString("comments"));
				return order;
			}
		});
		return orderList.toArray(new Order[orderList.size()]);
	}
	
	public Order[] searchCustomerPendingOrder(int customerId) {
		String cmd = "select * from Orders where orderStatus='pending' and customerId=?";
		List<Order> orderList = jdbcTemplate.query(cmd, new Object[] {customerId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order order = new Order();
				order.setorderId(rs.getInt("orderId"));
				order.setvendorId(rs.getInt("vendorId"));
				order.setcustomerId(rs.getInt("customerId"));
				order.setmenuId(rs.getInt("menuId"));
				order.setwalletId(rs.getInt("walletId"));
				order.setorderDate(rs.getDate("orderDate"));
				order.setquantityOrdered(rs.getInt("quantityOrdered"));
				order.setorderStatus(rs.getString("orderStatus"));
				order.setbillAmount(rs.getInt("billAmount"));
				order.setcomments(rs.getString("comments"));
				return order;
			}
		});
		return orderList.toArray(new Order[orderList.size()]);
	}
	public Order[] searchVendorPendingOrder(int vendorId) {
		String cmd = "select * from Orders where orderStatus='pending' and vendorId=?";
		List<Order> orderList = jdbcTemplate.query(cmd, new Object[] {vendorId}, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Order order = new Order();
				order.setorderId(rs.getInt("orderId"));
				order.setvendorId(rs.getInt("vendorId"));
				order.setcustomerId(rs.getInt("customerId"));
				order.setmenuId(rs.getInt("menuId"));
				order.setwalletId(rs.getInt("walletId"));
				order.setorderDate(rs.getDate("orderDate"));
				order.setquantityOrdered(rs.getInt("quantityOrdered"));
				order.setorderStatus(rs.getString("orderStatus"));
				order.setbillAmount(rs.getInt("billAmount"));
				order.setcomments(rs.getString("comments"));
				return order;
			}
		});
		return orderList.toArray(new Order[orderList.size()]);
	}
	
	//--------------
	public Order searchOrder(int orderId) {
		String cmd = "select * from orders where orderId=?";
		List<Order> orderList = jdbcTemplate.query(cmd, 
				new Object[] {orderId},
				new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
			 Order	orderFound = new Order();
				orderFound.setorderId(rs.getInt("orderId"));
				orderFound.setvendorId(rs.getInt("vendorId"));
				orderFound.setcustomerId(rs.getInt("customerId"));
				orderFound.setmenuId(rs.getInt("menuId"));
				orderFound.setwalletId(rs.getInt("walletId"));
				orderFound.setorderDate(rs.getDate("orderDate"));
				orderFound.setquantityOrdered(rs.getInt("quantityOrdered"));
				orderFound.setorderStatus(rs.getString("orderStatus"));
				orderFound.setbillAmount(rs.getInt("billAmount"));
				orderFound.setcomments(rs.getString("comments"));
				return orderFound;
			}
		});
		return orderList.get(0);
		
	}
	public String acceptOrRejectOrder(int orderId, int vendorId, String status) {
		Order order = searchOrder(orderId);
		if (order.getvendorId()==vendorId) {
			if (status.toUpperCase().equals("YES")) {
				String cmd = "Update orders set orderStatus='accepted' "
						+ " WHERE orderId=?";
				jdbcTemplate.update(cmd, new Object[] {orderId});
				return "Order Approved Successfully...";
			} else {
				String cmd = "Update orders set orderStatus='rejected' "
						+ " WHERE orderId=?";
				jdbcTemplate.update(cmd,new Object[] {orderId});
				cmd = "Update Wallet set Amount=Amount+? where walletId=?";
				jdbcTemplate.update(cmd, new Object[] {order.getbillAmount(), order.getwalletId()});
				return "Order Rejected Amount Refunded...";
			}
		} 
		return "You are unauthorized vendor...";
	}
	public String placeOrder(Order order)  {
		int orderId = generateOrderId();
		order.setorderStatus("pending");
		java.util.Date today = new Date();
		java.sql.Date dbDate = new java.sql.Date(today.getTime());
		order.setorderDate(dbDate);
		Menu menu=searchMenus(order.getmenuId()); // here i changed searchMenu To searchMenus
		int price = menu.getprice();
		int  billAmount = order.getquantityOrdered() * price;
		Wallet wallet =searchWallet(order.getwalletId());
		int Amount = wallet.getAmount();
		if (Amount - billAmount > 0) {
			order.setbillAmount(billAmount);
			order.setorderId(orderId);
			String cmd = "insert into Orders(orderId,vendorId,customerId,menuId,"
					+ "walletId,orderDate,quantityOrdered,orderStatus,billAmount,comments) "
					+ "values(?,?,?,?,?,?,?,?,?,?)";
			jdbcTemplate.update(cmd, new Object[] {
				order.getorderId(), order.getvendorId(),
				order.getcustomerId(),order.getmenuId(),
				order.getwalletId(), order.getorderDate(),
				order.getquantityOrdered(),order.getorderStatus(),
				order.getbillAmount(),order.getcomments()
			});
			deductBalance(order.getwalletId(), billAmount);
			return "Order Placed Successfully...Wallet Balance Deducted...";
		}
		return "Insufficient Funds...";
		//order.setBillAmount(billAmount);
	}
	
	public int generateOrderId()  {
		String cmd = "select case when max(orderId) is NULL THEN 1"
				+ " else max(orderId)+1 end orderId from orders";
		List<Object> orderId = jdbcTemplate.query(cmd, new RowMapper() {

			@Override
			public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
				Object ob = rs.getInt("orderId");
				return ob;
			}
		});
		return (Integer)orderId.get(0);
	}
	//----------------21-01-2022--------
	public Wallet searchWallet(int walletId) {
		String cmd = "select * from wallet where walletId=?";
		List<Wallet> walletList = jdbcTemplate.query(cmd, 
				new Object[] {walletId}, new RowMapper(){
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
						Wallet wallet = new Wallet();
						wallet.setwalletId(rs.getInt("walletId"));
						wallet.setcustomerId(rs.getInt("customerId"));
						wallet.setwalletType(rs.getString("walletType"));
						wallet.setAmount(rs.getInt("Amount"));
						return wallet;
					}
		});
		return walletList.get(0);
		
	}
	
	public Menu searchMenus(int menuId)  {
		String cmd = "select * from Menu where menuId=?";
		List<Menu> menuList = jdbcTemplate.query(cmd, 
				new Object[] {menuId}, new RowMapper(){
					@Override
					public Object mapRow(ResultSet rs, int rowNum) throws SQLException {
						Menu menu = new Menu();
						menu.setmenuId(rs.getInt("menuId"));
						menu.setrestaurentId(rs.getInt("restaurentId"));
						menu.setItemName(rs.getString("ItemName"));
						menu.setmenuType(rs.getString("menuType"));
						menu.setprice(rs.getInt("price"));
						return menu;
					}
		});
		return menuList.get(0);
	}
	
	public String deductBalance(int walletId, int billAmount) {
		String cmd = "update wallet set Amount=Amount-? where walletId=?";
		jdbcTemplate.update(cmd, new Object[] {billAmount,walletId});
		return "Amount Deducted...";
	}

	//-----------------/ 21-01-2022------


}
