package com.example.res;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurentApplicationTests {

	@Test
	void contextLoads() {
	}

}
