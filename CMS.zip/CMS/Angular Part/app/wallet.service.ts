import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Wallet } from './wallet';

@Injectable({
  providedIn: 'root'
})
export class WalletService {

  constructor(private _http: HttpClient) { }
  // showWallet(walletId : number): Observable<Wallet []> {
  //   return this._http.get<Wallet []>("http://localhost:8282/searchWallet/"+walletId)
  //     .pipe(
  //       tap(data =>
  //       console.log('All: ' + JSON.stringify(data)))
  //     );
  // }
  searchWallet(customerId : number): Observable<Wallet[] > {
    return this._http.get<Wallet[] >("http://localhost:8282/searchCustomerWallet/"+customerId)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
}
