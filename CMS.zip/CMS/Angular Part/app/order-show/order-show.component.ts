import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Order } from '../order';
import { OrderService } from '../order.service';


@Component({
  selector: 'app-order-show',
  templateUrl: './order-show.component.html',
  styleUrls: ['./order-show.component.css']
})
export class OrderShowComponent implements OnInit {

  customerId : number;
  vendorId : number;
  orders : Order[];
  orderId : number;
  //--------------------------------24-01-2022---
  acceptOrReject(orderId : number, vendorId : number) {
    this.orderId=orderId
    this.vendorId=vendorId;
    alert(this.orderId);
    alert(this.vendorId);
    localStorage.setItem("orderId",this.orderId.toString());
    localStorage.setItem("vendorId",vendorId.toString());
    this._router.navigate(['../acceptOrReject'], {relativeTo: this._route});
 }
 constructor(private _orderService:OrderService,private _route : ActivatedRoute,private _router : Router) { 
  this.vendorId = parseInt(localStorage.getItem("vendorId"));
  this._orderService.showVendorPendingOrder(this.vendorId).subscribe(
    {
      next: rs => {
        this.orders = rs;
      }

    }
  );
 //-----------------------/24-01-2022-----
  //constructor(private _orderService :OrderService) {
    this.customerId =parseInt(localStorage.getItem("customerId"));
    this._orderService.searchCustomerOrder(this.customerId).subscribe({
    next: rs =>{
      this.orders = rs;
      
      }
    })
      this.customerId =parseInt(localStorage.getItem("customerId"));
      this._orderService.showCustomerPendingOrder(this.customerId).subscribe({
      next: rs =>{
        this.orders = rs;
        
        }
      })

      this.vendorId =parseInt(localStorage.getItem("vendorId"));
      this._orderService.searchVendorOrder(this.vendorId).subscribe({
      next: rs =>{
        this.orders = rs;
        
        }
      })
      this.vendorId =parseInt(localStorage.getItem("vendorId"));
      this._orderService.showVendorPendingOrder(this.vendorId).subscribe({
      next: rs =>{
        this.orders = rs;
        
        }
      })

}
  ngOnInit(): void {
  }

}
