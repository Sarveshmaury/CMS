export class Wallet {
    public walletId : number;
    public customerId : number;
    public walletType : string;
    public amount: number;
    constructor(){

    }
}
