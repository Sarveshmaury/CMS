import { Restaurent } from './restaurent';

describe('Restaurent', () => {
  it('should create an instance', () => {
    expect(new Restaurent()).toBeTruthy();
  });
});
