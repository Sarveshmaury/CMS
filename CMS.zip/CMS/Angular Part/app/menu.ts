export class Menu {
    public menuId : number;
    public restaurentId : number;
    public itemName : string;
    public menuType : string;
    public price : number;
    constructor() {

    }
}
