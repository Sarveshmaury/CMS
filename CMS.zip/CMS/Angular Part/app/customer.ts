export class Customer {
    public customerId : number;
    public customername : string;
    public customerState : string;
    public customerCity: string;
    public customerEmail : string;
    public customerMob : string;
    constructor(){

    }
}
