import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';

@Component({
  selector: 'app-vendor-login',
  templateUrl: './vendor-login.component.html',
  styleUrls: ['./vendor-login.component.css']
})
export class VendorLoginComponent implements OnInit {

  vendorId : number;
  passCode : string;
  vendors : Vendor[];
  logMe() {
    localStorage.setItem('vendorId',this.vendorId.toString());
    if(this.passCode=="Mphasis") {
      this._router.navigate(['/vendorDashBoard']);
    }
  }
  constructor(private _router : Router, private _vendorService :VendorService) { 
    this._vendorService.showVendor().subscribe({
      next: rs =>{
        this.vendors = rs;
      }
    })
  }

 

  ngOnInit(): void {
  }

}
