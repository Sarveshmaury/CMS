import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Order } from './order';
import { Restaurent } from './restaurent';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private _http: HttpClient) { }
  searchCustomerOrder(customerId : number): Observable<Order[] > {
    return this._http.get<Order []>("http://localhost:8282/searchCustomerOrder/"+customerId)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  showCustomerPendingOrder(customerId : number): Observable<Order[] > {
    return this._http.get<Order []>("http://localhost:8282/searchCustomerPendingOrder/"+customerId)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }

  searchVendorOrder(vendorId : number): Observable<Order[] > {
    return this._http.get<Order []>("http://localhost:8282/searchVendorOrder/"+vendorId)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }

  showVendorPendingOrder(vendorId : number): Observable<Order[] > {
    return this._http.get<Order []>("http://localhost:8282/searchVendorPendingOrder/"+vendorId)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  //-----21-01-2022---
  showRestaurent(): Observable<Restaurent []> {
    return this._http.get<Restaurent []>("http://localhost:8282/showRestaurent")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }

  placeOrder(orders : Order) : Observable<string> {
    return this._http.post<string>("http://localhost:8282/order/placeOrder/",orders)
  }

  placeOrder1(orders : Order) : Observable<any> {
    return this._http.post<string>("http://localhost:8282/order/placeOrder",orders).
    pipe(tap(data => data.toString()))
  }
  //------/21-01-2022----

  //--24-01-2022---
  acceptOrReject(orderId : number,vendorId : number,status : string) : Observable<any> {
    return this._http.post("http://localhost:8282/acceptOrRejectOrder/"+orderId+"/"+vendorId+"/"+status,null ,  {"responseType": 'text'})
    .pipe(
      tap(data => {console.log("Place Order :"+data.toString()); return data.toString();})
    );
  }
  //----/-----

}
