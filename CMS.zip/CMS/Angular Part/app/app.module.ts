import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CustomerShowComponent } from './customer-show/customer-show.component';
import { VendorShowComponent } from './vendor-show/vendor-show.component';
import { RestaurentShowComponent } from './restaurent-show/restaurent-show.component';
import { CustomerDashBoardComponent } from './customer-dash-board/customer-dash-board.component';
import { VendorDashBoardComponent } from './vendor-dash-board/vendor-dash-board.component';
import { CustomerLoginComponent } from './customer-login/customer-login.component';
import { VendorLoginComponent } from './vendor-login/vendor-login.component';
import { HomePageComponent } from './home-page/home-page.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { OrderShowComponent } from './order-show/order-show.component';
import { WalletShowComponent } from './wallet-show/wallet-show.component';
import { PlaceOrderComponent } from './place-order/place-order.component';
import { AcceptOrRejectComponent } from './accept-or-reject/accept-or-reject.component';
//import { OrdersComponent } from './orders/orders.component';

const appRoutes : Routes = [
  {path:'',component:HomePageComponent},
  {path:'customerLogin',component:CustomerLoginComponent},
  {path:'vendorLogin',component:VendorLoginComponent},
  {path:'customerDashBoard',component:CustomerDashBoardComponent},
  {path:'vendorDashBoard',component:VendorDashBoardComponent},
  {path:'custDashBobard',component:CustomerDashBoardComponent, 
  children : [
    {path:'showRestaurant',component:RestaurentShowComponent,outlet:'mphasis'},
    {path:'showCustomer',component:CustomerShowComponent,outlet:'mphasis'},
    {path:'searchCustomerOrder',component:OrderShowComponent,outlet:'mphasis'},
    {path:'showCustomerPendingOrder',component:OrderShowComponent,outlet:'mphasis'},
    {path:'searchWallet',component:WalletShowComponent,outlet:'mphasis'},
    {path:'placeOrder',component:PlaceOrderComponent,outlet:'mphasis'},
    {path:'',component:HomePageComponent},

  ]
  
},
{path:'vendDashBobard',component:VendorDashBoardComponent,
  children : [
    {path:'showVendor',component:VendorShowComponent,outlet:'mphasis'},
    {path:'showRestaurant',component:RestaurentShowComponent,outlet:'mphasis'},
    {path:'showCustomer',component:CustomerShowComponent,outlet:'mphasis'},
    {path:'searchVendorOrder',component:OrderShowComponent,outlet:'mphasis'},
    {path:'showVendorPendingOrder',component:OrderShowComponent,outlet:'mphasis'},
    {path:'acceptOrReject',component:AcceptOrRejectComponent,outlet:'mphasis'},
  ]
}


]
@NgModule({
  declarations: [
    AppComponent,
    CustomerShowComponent,
    VendorShowComponent,
    RestaurentShowComponent,
    CustomerDashBoardComponent,
    VendorDashBoardComponent,
    CustomerLoginComponent,
    VendorLoginComponent,
    HomePageComponent,
    OrderShowComponent,
    WalletShowComponent,
    PlaceOrderComponent,
    AcceptOrRejectComponent,
    //OrdersComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
