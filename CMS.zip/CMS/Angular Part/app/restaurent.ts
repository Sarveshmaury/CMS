export class Restaurent {

    public restaurentId : number;
    public restaurentName : string;
    public restaurentCity : string;
    public restaurentBranch : string;
    public restaurentEmail : string;
    public restaurentContactNo : string;
    constructor(){

    }

}
