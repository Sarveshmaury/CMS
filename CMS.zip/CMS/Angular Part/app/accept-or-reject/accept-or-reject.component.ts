import { Component, OnInit } from '@angular/core';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-accept-or-reject',
  templateUrl: './accept-or-reject.component.html',
  styleUrls: ['./accept-or-reject.component.css']
})
export class AcceptOrRejectComponent implements OnInit {

  orderId : number;
  vendorId : number;
  status : string;
  result : string;
  acceptOrReject() {
    this._orderService.acceptOrReject(this.orderId,this.vendorId,this.status).subscribe(
      x =>{
        this.result = x;
      }
    )
    alert(this.result);
  }
  constructor(private _orderService : OrderService) {
    this.orderId = parseInt(localStorage.getItem("orderId"));
    this.vendorId = parseInt(localStorage.getItem("vendorId"));
   }

  ngOnInit(): void {
  }

}
