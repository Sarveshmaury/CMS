import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Menu } from './menu';

@Injectable({
  providedIn: 'root'
})
export class MenuService {

  constructor(private _http: HttpClient) { }

  showMenu(restaurentId : number): Observable<Menu[]> {
    return this._http.get<Menu[]>("http://localhost:8282/searchMenu/"+restaurentId)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }

  searchByMenuId(menuId : number): Observable<Menu> {
    return this._http.get<Menu>("http://localhost:8282/searchByMenuId/"+menuId)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
}
