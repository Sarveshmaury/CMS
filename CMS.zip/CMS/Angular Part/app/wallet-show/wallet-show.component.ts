import { Component, OnInit } from '@angular/core';
import { Wallet } from '../wallet';
import { WalletService } from '../wallet.service';

@Component({
  selector: 'app-wallet-show',
  templateUrl: './wallet-show.component.html',
  styleUrls: ['./wallet-show.component.css']
})
export class WalletShowComponent implements OnInit {

  customerId : number;
  wallets : Wallet [];
  constructor(private _walletService :WalletService) {
    this.customerId =parseInt(localStorage.getItem("customerId"));
    this._walletService.searchWallet(this.customerId).subscribe({
     next: rs =>{
       this.wallets = rs;
      
      }
    })
 }
  ngOnInit(): void {
  }

}
