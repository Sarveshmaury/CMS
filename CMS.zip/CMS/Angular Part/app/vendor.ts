export class Vendor {
    public vendorId : number;
    public vendorName : string;
    public vendorState : string;
    public vendorCity: string;
    public vendorEmail : string;
    public vendorMob : string;
    constructor(){

    }
}
