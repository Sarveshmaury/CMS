import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Menu } from '../menu';
import { MenuService } from '../menu.service';
import { Order } from '../order';
import { OrderService } from '../order.service';
import { Restaurent } from '../restaurent';
import { RestaurentService } from '../restaurent.service';
import { Vendor } from '../vendor';
import { VendorService } from '../vendor.service';
import { Wallet } from '../wallet';
import { WalletService } from '../wallet.service';

@Component({
  selector: 'app-place-order',
  templateUrl: './place-order.component.html',
  styleUrls: ['./place-order.component.css']
})
export class PlaceOrderComponent implements OnInit {

  menus : Menu[];
  result : any;
  res : string;
  insert(placeOrder : NgForm) {
    alert("Hi");
    alert(this.orders.quantityOrdered);
    alert(this.orders.menuId);
    this.orders.customerId = this.customerId;
    alert(this.orders.customerId);
    alert(this.orders.vendorId);
    alert(this.orders.walletId); 
    alert(this.orders.comments);
    this._orderService.placeOrder1(this.orders).subscribe(x =>{
      this.result=x;
   //   alert(x);
   })
  alert(this.result);
  } 
  customerId : number;
  restaurents : Restaurent[];
  vendors : Vendor[];
  restaurentId : number;
  wallets : Wallet[];
  orders : Order;
  menu : Menu;
  price : number;
  showm() {
    alert(this.orders.menuId);
    this._menuService.searchByMenuId(this.orders.menuId).subscribe(x => {
      this.price = x.price;
    })
  }
  show() {
    alert(this.restaurentId);
    this._menuService.showMenu(this.restaurentId).subscribe(x => {
      this.menus = x;
    });
  }
  showv() {
    alert(this.orders.vendorId);
  }
  showW() {
    alert(this.orders.walletId);
  }
  constructor(private _restaurentSerivce : RestaurentService,
              private _menuService : MenuService, 
              private _vendorService : VendorService,
              private _walletService : WalletService,
              private _orderService : OrderService
        ) {
    this.orders = new Order();
    this.customerId = parseInt(localStorage.getItem("customerId"));
    this._walletService.searchWallet(this.customerId).subscribe(x => {
      this.wallets = x;
    });
    this._restaurentSerivce.showRestaurent().subscribe(x => {
      this.restaurents=x;
    });
    this._vendorService.showVendor().subscribe(x => {
      this.vendors = x;
    })
   }

  ngOnInit(): void {
  }

}
