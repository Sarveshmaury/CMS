import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-customer-dash-board',
  templateUrl: './customer-dash-board.component.html',
  styleUrls: ['./customer-dash-board.component.css']
})
export class CustomerDashBoardComponent implements OnInit {

  customerId : number;
  customer : Customer;
  constructor(private _customerService : CustomerService) { 
    this.customerId =parseInt(localStorage.getItem("customerId"));
    this._customerService.searchCustomer(this.customerId).subscribe(x => {
      this.customer=x;
    })
   // this.customer = this._customerService.searchCustomer(this.customerId);
  }

  ngOnInit(): void {
  }

}
