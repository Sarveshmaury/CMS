import { Component, OnInit } from '@angular/core';
import { Restaurent } from '../restaurent';
import { RestaurentService } from '../restaurent.service';

@Component({
  selector: 'app-restaurent-show',
  templateUrl: './restaurent-show.component.html',
  styleUrls: ['./restaurent-show.component.css']
})
export class RestaurentShowComponent implements OnInit {

  restaurents : Restaurent[];
  constructor(private _restaurentService :RestaurentService) {
  this._restaurentService.showRestaurent().subscribe({
    next: rs =>{
      this.restaurents = rs;
    }
  })
}

  ngOnInit(): void {
  }

}
