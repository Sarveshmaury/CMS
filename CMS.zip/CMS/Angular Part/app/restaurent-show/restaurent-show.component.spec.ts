import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RestaurentShowComponent } from './restaurent-show.component';

describe('RestaurentShowComponent', () => {
  let component: RestaurentShowComponent;
  let fixture: ComponentFixture<RestaurentShowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RestaurentShowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurentShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
