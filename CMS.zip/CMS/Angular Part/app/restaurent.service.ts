import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Restaurent } from './restaurent';
@Injectable({
  providedIn: 'root'
})
export class RestaurentService {

  constructor(private _http: HttpClient) { }

  showRestaurent(): Observable<Restaurent []> {
    return this._http.get<Restaurent []>("http://localhost:8282/showRestaurent")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
}

